from swagger_server.API_main import main

application = main()
